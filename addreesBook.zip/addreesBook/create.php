<?php
if (isset($_REQUEST['submit'])){
if (!isset($_REQUEST['name']) OR !isset($_REQUEST['phone']) OR !isset($_REQUEST['email']) OR !isset($_REQUEST['address']))
{
    echo "<script>
document.getElementById('submit').setAttribute('btn btn-danger');

</script>";
}
   //$query = "insert into address(name,phoneNum,email,address,dp) VALUES ('$name','$phone','$email','$address','$pp')";
    //$sql = mysqli_query($conn,"$query");
    //if ($conn->query($query)){
       // $registered=$conn->affected_rows;
      //  echo "$registered row saved successfully";
   // }else {
   //     echo $conn->error;
    //}

    $cre_object = new image();
    $cre_object->name = $_REQUEST['name'];
    $cre_object->phone = $_REQUEST['phone'];
    $cre_object->email = $_REQUEST['email'];
    $cre_object->address = $_REQUEST['address'];
    //$cre_object->pp = $_REQUEST['pic'];

    $cre_object->insert_image();
}
    class image {
        var
            $img_name;
        var
            $img_id;
        var
            $image;
        var
            $name;
        var
            $phone;
        var
            $address;
        var
            $email;
        var
            $pp;

        function insert_image() {
           // if ($_FILES['profilePic']){
                $tmpname=$_FILES['profilePic']['tmp_name'];
                $truename=$_FILES['profilePic']['name'];
                //$size=($_FILES['profilePic']['size'] / 5242880) . "MB<br />";
                $type=$_FILES['profilePic']['type'];
               // $image=$_FILES['profilePic']['name'];
                move_uploaded_file($_FILES['profilePic']['tmp_name'], "images/".$_FILES['profilePic']['name']);
                //move_uploaded_file($tmpname, "images/$truename");

           // }
            $conn = new mysqli("localhost", "root", "admin123", "addressBook");
            $sql="INSERT INTO  `address`(`name`, `phoneNum`, `email`, `address`, `dp`) VALUES ( \"$this->name\", \"$this->phone\", \"$this->email\", \"$this->address\", \"$truename\" )";
            if($conn->query($sql)){
                echo "<script lang='javascript' type='text/javascript'>alert('Record saved successfully');</script>";
            } else {
                echo "<script lang='javascript' type='text/javascript'>alert('Record was not saved');</script>";
            }
        }

    }


?>

    <!--meta name="viewport" content="width=device-width, initial-scale=1"-->
<html>
<head>
    <title>Address Book</title>
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="bootstrap/js/html5shiv.min.js"></script>
    <script src="bootstrap/js/respond.min.js"></script>
    <![endif]-->
    <style>
        #form{
            border: #161cff 100px;
            padding-right: 100px ;
            padding-left: 100px;
        }
    </style>
</head>
<body>
<h3 ALIGN="center" style="color: ">WELCOME TO DIMAT PHONEBOOK</h3><hr/><br /><br />
<div align="center">
    <form id="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
        <table cellpadding="10" border="2" align="center">
            <tr class="bg-danger">
                <th><label for="name">Name: </label></th>
                <td width="50%"><input type="text" name="name" required/></td>
            </tr>
            <tr class="warning">
                <th><label for="phone">Phone Number: </label></th>
                <td><input type="tel" name="phone" required /></td>
            </tr>
            <tr class="alert-danger">
                <th><label for="email">Email Address: </label></th>
                <td><input type="email" name="email" required/></td>
            </tr>
            <tr class="active">
                <th><label for="address">Address: </label></th>
                <td><input type="text" name="address" required /></td>
            </tr>
            <tr class="bg-danger">
                <th><label for="profilePic">Profile Picture: </label></th>
                <td><input type="file" name="profilePic" required /></td>
            </tr>
            <tr class="btn-success">
                <td colspan="2" id="submit" align="right"><input type="submit" name="submit" class="btn btn-warning" value="Save" /></td>
            </tr>
        </table>

    </form>
</div>
<br />
<?php require_once ("links.php"); ?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="bootstrap/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
