<!DOCTYPE html>
<!--
Created using JS Bin
http://jsbin.com

Copyright (c) 2016 by anonymous (http://jsbin.com/quwiyazepe/1/edit)

Released under the MIT license: http://jsbin.mit-license.org
-->
<meta name="robots" content="noindex">
<html>
<head>
    <link class="jsbin" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />
    <script class="jsbin" src="../bootstrap/js/jquery.min.js"></script>
    <script class="jsbin" src="../bootstrap/js/jquery-ui.min.js"></script>
    <meta charset=utf-8 />
    <title>JS Bin</title>
    <!--[if IE]>
    <script src="../bootstrap/js/html5shiv.min.js"></script>
    <![endif]-->
    <style>
        article, aside, figure, footer, header, hgroup,
        menu, nav, section { display: block; }

    </style>
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data" >
<input type='file' onchange="readURL(this);" name="pic"/>
<input type="submit" value="Update Picture" name="submit" />
<img id="blah" src="#" alt="Preview" />
</form>
<script id="jsbin-javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(160)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<button onclick="window.location.href='<?php echo $_REQUEST['profile'];?>' " class="btn btn-success">BACK</button>
</body>
</html>

<?php

if (isset($_POST['submit'])) {

    if (isset($_FILES['pic'])) {
        $picture = $_FILES['pic']['name'];
        $picturetmp = $_FILES['pic']['tmp_name'];
        //$tmpname = $_FILES["$picture"]['tmp_name'];
        //$truename = $_FILES['pic']['name'];
        //$size = ($_FILES['pic']['size'] / 5242880) . "MB<br />";
        //$type = $_FILES['pic']['type'];
        $ext = pathinfo($picture, PATHINFO_EXTENSION);
        // $image=$_FILES['profilePic']['name'];
        if(file_exists($picture)){
            echo "Picture already chosen";
            var_dump($picture);
            exit();
        }
        move_uploaded_file($_FILES['pic']['tmp_name'], "../images/" . $picture);


    }

    $picture = $_FILES['pic']['name'];
    if ($picture != NULL) {
        $ext = pathinfo("$picture", PATHINFO_EXTENSION);
        /*if ($ext == "jpeg") {

            $pictures = explode(".", "$picture");
            $picture = $pictures[0] . ".jpg";

        }*/
        $id = $_REQUEST['ids'];

        $conn = new mysqli("localhost", "root", "admin123", "addressbook");
        if ($conn->error) {
            die("Connection Error" . $conn->error);
        }

        $query = "UPDATE `address` SET `dp` = '$picture' WHERE `address`.`addressId` = $id;";
        if ($conn->query($query)) {
            echo "<script>alert('Update Successful!');</script>";
            include_once ("../links.php");
            // header("Location:profile.php");
        } else
            echo "<script> alert(\"$conn->error\");</script>";
    } else {
        var_dump($picture);
        echo "<script>alert('Please Choose a Picture!')</script>";
        //exit(0);
    }

}

?>


   <!-- <input type="file" name="pic" placeholder="Choose Profile" id="files" />
    <input type="submit" name="preview" value="Preview" id="go"/>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../bootstrap/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src=../bootstrap/js/bootstrap.min.js"></script>