<?php
session_start();
$conn=new mysqli("localhost", "root", "admin123", "addressbook");
if($conn->error){
    die("Error connecting to OR Choosing database");
}
$picture=$_REQUEST['pic'];
$email= $_REQUEST['emails'];
$phone=$_REQUEST['phones'];
$address=$_REQUEST['addresss'] ;
$id=$_REQUEST['ids'];

session_id($id);
$profile=$_SERVER['HTTP_REFERER'];
?>

<html>
<head>
    <title><?php echo "<-" . $_REQUEST['names'] . "->PROFILE"; ?></title>

    <link type="text/css" href="style.css" rel="stylesheet" />
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]-->
    <script src="bootstrap/js/html5shiv.min.js"></script>
    <script src="bootstrap/js/respond.min.js"></script>
</head>
<body>
<h3 class="intro" align="center"><button onclick="document.location.href='<?php echo $_REQUEST['viewall']; ?>'" class="btn btn-success">Back</button><?php echo "Welcome " . $_REQUEST['names']. "<br /><h5 align='center' id='inner'><i>We're Please to've You!</i></h5>"; ?></h3>

<div id="container">
    <div id="header">
        <table border="0">
            <tr>
                <td align="left" width="50%">
            <h3 id="heading">Di-Mat Contact Server</h3>
                </td>
                <td align="right" width="50%">
            <img id="img" src='<?php echo"images/$picture" ?>' width="70" height="60"/>&nbsp;&nbsp;<?php echo "<button onclick='window.location.href=\"pedit/editPPicture.php?ids=$id&profile=$profile\"'>Change Picture</button>" ?>
                </td>
            </tr>
        </table>

    </div>
    <div id="content">
       <div id="nav">
           <ul class="list">
               <li><a href="">Home</a></li>
               <li><a href="">Profile</a></li>
               <li><a href="">Find Others</a></li>
               <li><a href="">About</a></li>
           </ul>
       </div>
        <div id="main">
            <table cellpadding="">
                <tr>
                    <th width="50%">ID</th>
                    <td width="50%"><?php echo $id; ?></td>
                    <td width="50%"><a href="">Edit</a></td>
                </tr>
                <tr>
                    <th width="50%">Email</th>
                    <td width="50%"><?php echo $email; ?></td>
                    <?php echo "
                    <td width=\"50%\"><a href=\"\">Edit</a></td>
                    "
                    ?>
                    </tr>
                <tr>
                    <th width="50%">Phone</th>
                    <td width="50%"><?php echo $phone; ?></td>
                    <td width="50%"><a href="">Edit</a></td>
                </tr>
                <tr>
                    <th width="50%">Address</th>
                    <td width="50%"><?php echo $address; ?></td>
                    <td width="50%"><a href="">Edit</a></td>
                </tr>
            </table>
        </div>
        </div>
        <div id="footer"></div>
    </div>

</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="bootstrap/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
