<!DOCTYPE html>
    <html>
<head>
    <title>Address Book</title>
</head>
<body>
<a href="create.php">Add Contact</a> &nbsp;
<a href="search.php">Search Contact</a>
</body>
</html>