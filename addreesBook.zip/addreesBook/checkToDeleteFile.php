<?php
$conn=new mysqli("localhost", "root", "admin123", "addressbook");
if ($conn->error){
    die("Database Connection Failed" . $conn->error);
        }
        $ids=$_REQUEST['id'];
        $picture=$_REQUEST['picname'];
        //$ext = pathinfo($picture, PATHINFO_EXTENSION);
    $query="SELECT `dp` FROM  `address` WHERE `dp`=$picture";
    if ($row=$conn->query($query)==1) {
        while ($file = readdir($dirHandle)) {
            if ($file == $picture) {
                unlink($path_to_file . '/' . $picture);
            }
        }
        closedir($dirHandle);
    }
?>