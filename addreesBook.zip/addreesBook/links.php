<!-- Bootstrap -->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]-->
<script src="bootstrap/js/html5shiv.min.js"></script>
<script src="bootstrap/js/respond.min.js"></script>
<div align="center" class="btn-group">
<button class="btn btn-success" onclick="window.location.href='create.php'" style="text-decoration: none">Create</button>&nbsp;
<button class="btn btn-primary" onclick="document.location.href='view.php'" style="text-decoration: none">View All</button>&nbsp;
<button class="btn btn-inverse" onclick="document.location.href='search.php'" style="text-decoration: none">Search</button>&nbsp;
<button class="btn btn-warning" onclick="window.location.href='mupdate.php'" style="text-decoration: none">Update</button>&nbsp;
<button class="btn btn-danger" onclick="document.location.href='mdelete.php'" style="text-decoration: none">Delete</button>&nbsp;

</div>