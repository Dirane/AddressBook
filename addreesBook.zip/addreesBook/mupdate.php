<html>
<head><title>Search</title>
    <style>
        body{
            background-image: url();
            background-repeat: repeat;
            padding: 50px;
            border: #161cff;
        }
    </style></head>
<body>
    <h3 align="center" style="color: #161cff">Update Record</h3>
    <h6 align="center"><i>Click name to update</i></h6>
<div align="center">

<br />
<?php

    $conn = new mysqli("localhost","root","admin123","addressbook");
    $sql = "SELECT * FROM `address`";
    $result=$conn->query($sql);
    if($result->num_rows > 0){
        echo " <table border='5px solid black' align='center' cellpadding='15px' bgcolor='white'>
            <tr bgcolor='orange'> 
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Address</th>
            </tr>";
        while($row=$result->fetch_assoc()){
            $id=$row['addressId'];
            $name=ucwords(strtolower($row['name']));
            $phone=$row['phoneNum'];
            $email=$row['email'];
            $address=$row['address'];
            echo "
             <tr> 
               <td><a href=\"update.php?i=$id&n=$name&p=$phone&e=$email&a=$address\" style='text-decoration: none; color: deepskyblue;' >$name</a></td>
                                                                                           <td>".$row['phoneNum']."</td>
                                                                                           <td>".$row['email']."</td>
                                                                                           <td>".$row['address']."</td>
                                                       
            </tr>
            
            
            ";
        }
    } else {
        echo "<p align='center'>Sorry, No Match found</p>";
    }
    echo "</table>";

    echo "<p align='center'><a href='index.php' style=' text-decoration: none; color: chartreuse'>HOME</a> </p> ";
    $conn->close();


?>
    <?php require_once ("links.php"); ?>
</body>
</html>
