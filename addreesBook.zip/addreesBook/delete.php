<?php
$con=new mysqli("localhost", "root", "admin123", "addressbook");
if($con->error) {
    die("Access Denied: " . $con->error);
}
else {
    $ids = $_REQUEST['id'];
    $picture = $_REQUEST['picname'];
    $sql = "DELETE FROM `address` WHERE `addressId`= " . $ids . "";

    $query = "SELECT `dp` FROM  `address` WHERE `address`.`dp`=\"$picture\"";


    if ($con->query($query)) {
        $result = $con->query($query);

        /**
         * CHECK IF PICTURE IS SHARED
         */
        if ($result->num_rows > 0 AND $result->num_rows < 2) {
            $path_to_file = "images";
            $dirHandle = opendir($path_to_file);
            /**
             * DELETE PICTURE IF NOT SHARED
             */
            while ($file = readdir($dirHandle)) {
                if ($file == $picture) {
                    unlink($path_to_file . '/' . $picture);
                }
            }
            closedir($dirHandle);


        }
        /**
         *  DELETE RECORD FROM DATABASE
         */

        if ($con->query($sql) === TRUE) {
            //DO NOTHING
            //else exit(0);
            /*  while ($file=readdir($dirHandle)){
                  if ($file==$picture){
                      unlink($path_to_file.'/'.$picture);
                  }
              }
              closedir($dirHandle); */
            //$path=$_SERVER['DOCUMENT_ROOT']."/PhpstormProjects/addressbook/images/".$picture;
            //unlink($path);
            echo "Record Delete Success<br />";
            echo "<button onclick='document.location.href=\"mdelete.php\"'><img src='images/back-button-300x120.png' width='60' height='20' /></button>";
            include_once("links.php");
        } else echo $con->error;

    } else echo $con->error;
}
$con->close();

?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="bootstrap/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
