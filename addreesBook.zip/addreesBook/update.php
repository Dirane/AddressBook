<?php

    update();
            function update()
            {
                $conn = new mysqli("localhost", "root", "admin123", "addressbook");
                if ($conn->error) {
                    die("Database inaccessible: $conn->error");
                }
                $id=$_REQUEST['i'];
                $name=$_REQUEST['n'];
                $phone=$_REQUEST['p'];
                $email=$_REQUEST['e'];
                $address=$_REQUEST['a'];

                $title=array("<h3>Editing Record: ". $id ." </h3>", "<h3 style='color:#00bfff;'>Update Successful ". $id ." </h3>");
                echo "
                <table cellpadding='2' width='30' bgcolor='white' align='center'>
                <tr><th align='center' bgcolor='#00bfff' colspan='2'>$title[0]</th></tr>
                       <form action='' method='post'>
                           <tr> <td>Name:</td> <td><input type='text' name='name' value='$name' /></td></tr> 
                            <tr><td>Phone: </td><td><input value='$phone' name='phone' type='text' /></td></tr>
                            <tr><td>Email:</td><td><input name='email' value='$email' type='text'/></td> </tr>
                            <tr><td>Address:</td><td><input name='address' type='text' value='$address' /></td></tr>
                            <tr><td colspan='2' align='right'><input type='submit' name='submit' value='Update'/></td></tr>

                        </form>
                </table>
                        ";
                if (isset($_REQUEST['submit'])) {
                    $nam = $_POST['name'];
                    $phon = $_POST['phone'];
                    $emai = $_POST['email'];
                    $addres = $_POST['address'];

                    $sql = "UPDATE `address` SET `name`=\"$nam\", `phoneNum`=\"$phon\", `email`=\"$emai\", `address`=\"$addres\" WHERE `addressId`=\"$id\"";
                    if ($conn->query($sql)===TRUE) {
                        echo "$title[1]";
                        include_once ("links.php");
                    } else {
                        echo $conn->error;
                    }
            
                    }
            }


?>