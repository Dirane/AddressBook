
<html>
<head><title>Search</title>
<style>
    body{
        background-image: url();
        background-repeat: repeat;
        padding: 50px;
        border: #161cff;
    }
</style>
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]-->
    <script src="bootstrap/js/html5shiv.min.js"></script>
    <script src="bootstrap/js/respond.min.js"></script>
</head>
<body>
<div align="center">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
    <input type="text" name="search" placeholder="search by name">
    <input type="submit" name="submit" value="Search">

</form></div>
<hr/>
<br />
<?php

if(isset($_REQUEST['submit'])){
    $search = $_POST['search'];
    $conn = new mysqli("localhost","root","admin123","addressbook");
    $sql = "SELECT * FROM `address` WHERE `name` LIKE '%$search%'";
    $result=$conn->query($sql);
    if($result->num_rows > 0){
       echo " <table border='5px solid black' align='center' cellpadding='15px' bgcolor='white'>
            <tr bgcolor='orange'> 
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Address</th>
            </tr>";
        while($row=$result->fetch_assoc()){
            $id=$row['addressId'];
            $name=ucwords(strtolower($row['name']));
            $phone=$row['phoneNum'];
            $email=$row['email'];
            $address=$row['address'];
            echo "
             <tr> 
                                                                                                <td>$name</a></td>
                                                                                           <td>".$row['phoneNum']."</td>
                                                                                           <td>".$row['email']."</td>
                                                                                           <td>".$row['address']."</td>
                                                       
            </tr>
            
            
            ";
        }
    } else {
        echo "<p align='center'>Sorry, No Match found</p>";
    }
    echo "</table>";

    echo "<p align='center'><a href='index.php' style=' text-decoration: none; color: chartreuse'>HOME</a> </p> ";
    $conn->close();

}
?>
<?php require_once ("links.php"); ?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="bootstrap/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
