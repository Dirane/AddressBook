<html>
<head><title>Search</title>
    <style>
        body{
            background-image: url();
            background-repeat: repeat;
            padding: 50px;
            border: #161cff;
        }
    </style></head>
<body>
<h3 align="center" style="color: chartreuse">View All Records</h3>
<br />
<?php

    $conn = new mysqli("localhost","root","admin123","addressbook");
    $sql = "SELECT * FROM `address`";
    $result=$conn->query($sql);
    if($result->num_rows > 0){
        echo " <table border='5px solid black' align='center' cellpadding='1px' bgcolor='white'>
            <tr bgcolor='orange'> 
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Address</th>
                <th>Profile Picture</th>
            </tr>";
        while($row=$result->fetch_assoc()){
            $id=$row['addressId'];
            $name=strtoupper($row['name']);
            $phone=$row['phoneNum'];
            $email=$row['email'];
            $address=ucfirst(strtolower($row['address']));
            $dp=$row['dp'];
            $viewall = $_SERVER['HTTP_REFERER'];
            echo "
             <tr align='center' style='color: #161cff; font-weight: bold' > 
               <td width='20%'><a href='profile.php?ids=$id&names=$name&pic=$dp&phones=$phone&emails=$email&addresss=$address&viewall=$viewall'>$name</a></td>
                                                                                           <td width='20%'>".$row['phoneNum']."</td>
                                                                                           <td width='20%'>".$row['email']."</td>
                                                                                           <td width='20%'>".$row['address']."</td>
                                                       <td align='center' width='10%'><img src='images/".$row['dp']."' width='60' height='60'/></td>
                                                      
            </tr>
            
            
            ";

        }
    } else {
        echo "<p align='center' style='color: #161cff'>No Record Found</p>";
    }
    echo "</table>";

    echo "<p align='center'><a href='index.php' style=' text-decoration: none; color: chartreuse'>HOME</a> </p> ";
    $conn->close();


?>
<?php require_once ("links.php"); ?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="bootstrap/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
