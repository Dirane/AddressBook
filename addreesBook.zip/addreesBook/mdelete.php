<html>
<head><title>Search</title>
    <style>
        body{
            background-image: url();
            background-repeat: repeat;
            padding: 50px;
            border: #161cff;
        }
    </style></head>
<body>
<h3 align="center" style="color: chartreuse"> Delete Record </h3>
<?php

    $conn = new mysqli("localhost", "root", "admin123", "addressbook");
    $sql = "SELECT * FROM `address`";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo " <table border='5px solid black' align='center' cellpadding='15px' bgcolor='white' id='main'>
            <tr bgcolor='orange'> 
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Address</th>
                <th>Alter</th>
            </tr>";
        while ($row = $result->fetch_assoc()) {
            $id = $row['addressId'];
            $name = ucwords(strtolower($row['name']));
            $phone = $row['phoneNum'];
            $email = $row['email'];
            $address = $row['address'];
            $img = $row['dp'];
            echo "
             <tr> 
               <td>$name</td>
                                                                                           <td>" . $row['phoneNum'] . "</td>
                                                                                           <td>" . $row['email'] . "</td>
                                                                                           <td>" . $row['address'] . "</td>
                                                       <td><a href=\"delete.php?id=$id&picname=$img\" onclick='if(!confirm(\"Are you sure..?\")){ event.preventDefault();}'>Delete</a></td>
            </tr>
            
            
            ";
        }
    } else {
        echo "<p align='center'>No Record found</p>";
    }
    echo "</table>";

    echo "<p align='center'><a href='index.php' style=' text-decoration: none; color: chartreuse'>HOME</a> </p> ";
    $conn->close();


?>
<?php require_once ("links.php"); ?>
</body>
</html>
